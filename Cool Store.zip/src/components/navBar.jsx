import "./navBar.css";



const NavBar = () => {
    return (
        <div className="navBar">
            <h5>Nav menu will be here</h5>
            

           
        </div>
    );
}

export default NavBar;